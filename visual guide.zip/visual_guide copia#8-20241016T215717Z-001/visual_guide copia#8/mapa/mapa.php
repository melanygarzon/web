<?php
// Configuración de la conexión
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "visual_guide";

$conn = new mysqli($servername, $username, $password, $dbname);

// Manejo de errores de conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta para obtener coordenadas activas
$sql = "SELECT * FROM reporte WHERE activo = 1";
$result = $conn->query($sql);

if (!$result) {
    die("Error en la consulta: " . $conn->error);
}

$coordenadas = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $coordenadas[] = $row;
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mapa con Formulario Modal</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js"></script>
    <style>
    /* Estilo para el mapa */
    #mapa {
        height: 400px;
        width: 100%;
        margin-top: 20px;
        border-radius: 5px;
        border: 2px solid #acf5a0; /* Borde verde suave */
    }

    /* Aplicar estilos similares a container-card */
    .modal {
        display: none;
        position: fixed;
        z-index: 1000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7); /* Oscuro translúcido */
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .modal-content {
        background-color: rgba(36, 248, 3, 0.414); /* Verde translúcido */
        padding: 20px;
        border-radius: 5px;
        width: 300px;
        color: #000; /* Texto negro para contraste */
        box-shadow: 0px 1px 10px rgba(36, 248, 3, 0.5); /* Sombra verde */
    }

    .modal-content h2, .modal-content label, .modal-content select, .modal-content input, .modal-content button {
        color: #acf5a0; /* Verde suave */
    }

    .close {
        position: absolute;
        top: 10px;
        right: 10px;
        font-size: 24px;
        color: #acf5a0; /* Verde suave */
        cursor: pointer;
    }

    /* Botón de abrir modal */
    #openModal {
        background-color: rgba(36, 248, 3, 0.414); /* Verde translúcido */
        color: #000; /* Texto negro para contraste */
        padding: 10px 20px;
        border-radius: 5px;
        border: 1px solid #acf5a0; /* Borde verde suave */
        cursor: pointer;
        margin-bottom: 20px;
        transition: all 400ms ease;
    }

    #openModal:hover {
        background-color: #acf5a0; /* Verde suave */
        color: #000; /* Negro */
    }

    /* Estilos para el botón "Guardar" */
    button[type="submit"] {
        background-color: rgba(36, 248, 3, 0.414); /* Verde translúcido */
        color: #000; /* Negro */
        padding: 10px;
        border: 1px solid #acf5a0; /* Borde verde suave */
        border-radius: 5px;
        cursor: pointer;
        transition: all 400ms ease;
    }

    button[type="submit"]:hover {
        background-color: #acf5a0; /* Verde suave */
        color: #000; /* Negro */
    }
</style>

</head>
<body>

    <h1 class="title-cards">Mapa interactivo de Visual Guide</h1>
    <button id="openModal">Ingresar coordenadas manualmente</button>
    <div id="mapa"></div>

    <!-- Modal para ingresar coordenadas -->
    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close" id="closeModal">&times;</span>
            <h2>Ingresar Coordenadas</h2>
            <form id="formularioCoordenadas">
                <label for="latitud">Latitud:</label>
                <input type="text" id="latitud" name="latitud" required><br><br>

                <label for="longitud">Longitud:</label>
                <input type="text" id="longitud" name="longitud" required><br><br>

                <label for="etiqueta">Etiqueta:</label>
                <select id="etiqueta" name="etiqueta" required>
                    <option value="1">Obstáculo</option>
                    <option value="2">Hueco</option>
                </select><br><br>

                <button type="submit">Guardar</button>
            </form>
        </div>
    </div>

    <script>
        // Inicializar el mapa
        var mapa = L.map('mapa').setView([6.276669, -75.619795], 16);

        // Cargar los tiles de OpenStreetMap
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        }).addTo(mapa);

        // Añadir los marcadores al mapa
        <?php foreach ($coordenadas as $coordenada): ?>
            var icono = L.icon({
                iconUrl: '<?php echo $coordenada['id_accion'] == 1 ? 'obstaculo.png' : 'hueco.png'; ?>',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
            });
            L.marker([<?php echo $coordenada['lat']; ?>, <?php echo $coordenada['long']; ?>], { icon: icono })
                .addTo(mapa)
                .bindPopup("Etiqueta: <?php echo $coordenada['id_accion'] == 1 ? 'Obstáculo' : 'Hueco'; ?>");
        <?php endforeach; ?>

        // Modal
        var modal = document.getElementById("modal");
        var btnAbrir = document.getElementById("openModal");
        var btnCerrar = document.getElementById("closeModal");

        btnAbrir.onclick = function() {
            modal.style.display = "flex";
        }

        btnCerrar.onclick = function() {
            modal.style.display = "none";
        }

        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        // Manejo del formulario de coordenadas
        document.getElementById("formularioCoordenadas").addEventListener("submit", function(event) {
            event.preventDefault();

            var latitud = document.getElementById("latitud").value;
            var longitud = document.getElementById("longitud").value;
            var etiqueta = document.getElementById("etiqueta").value;

            var icono;
            if (etiqueta === "1") {
                icono = L.icon({
                    iconUrl: 'obstaculo.png',
                    iconSize: [25, 41],
                    iconAnchor: [12, 41],
                });
            } else {
                icono = L.icon({
                    iconUrl: 'hueco.png',
                    iconSize: [25, 41],
                    iconAnchor: [12, 41],
                });
            }

            fetch('guardar_coordenadas.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'lat=' + latitud + '&lng=' + longitud + '&etiqueta=' + etiqueta
            }).then(response => response.text())
              .then(data => {
                  var marcador = L.marker([latitud, longitud], { icon: icono }).addTo(mapa);
                  marcador.bindPopup("Etiqueta: " + (etiqueta === "1" ? "Obstáculo" : "Hueco")).openPopup();

                  modal.style.display = "none";
              })
              .catch(error => console.error('Error al guardar las coordenadas:', error));
        });
    </script>

</body>
</html>
