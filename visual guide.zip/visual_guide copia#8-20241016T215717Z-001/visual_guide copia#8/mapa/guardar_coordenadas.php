<?php
// guardar_coordenadas.php

// Conectar a la base de datos (ajusta los parámetros según tu configuración)
$host = 'localhost'; // o tu host
$db = 'visual_guide'; // nombre de tu base de datos
$user = 'root'; // tu usuario
$pass = ''; // tu contraseña

// Crear conexión
$conn = new mysqli($host, $user, $pass, $db);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos del formulario
$latitud = (float) $_POST['lat']; // Asegurarte que sea un float
$longitud = (float) $_POST['lng']; // Asegurarte que sea un float
$id_usuario = 1; // Cambia esto según tu lógica de usuario
$id_accion = $_POST['etiqueta']; // 1 para obstáculo, 2 para hueco
$activo = 1; // Activo por defecto

// Preparar la consulta SQL
$stmt = $conn->prepare("INSERT INTO reporte (id_usuarios, id_accion, `long`, `lat`, `activo`) VALUES (?, ?, ?, ?, ?)");

if ($stmt === false) {
    die("Error en la preparación de la consulta: " . $conn->error);
}

// Vincular los parámetros
$stmt->bind_param("iiddi", $id_usuario, $id_accion, $longitud, $latitud, $activo);

// Ejecutar la consulta
if ($stmt->execute()) {
    echo "Reporte guardado exitosamente.";
} else {
    echo "Error al guardar el reporte: " . $stmt->error;
}

// Cerrar la conexión
$stmt->close();
$conn->close();
?>
