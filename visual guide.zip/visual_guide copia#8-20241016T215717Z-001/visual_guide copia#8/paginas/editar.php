<?php
include_once("../modulos/conexion.php");
include_once("../modulos/header.php");
include_once("../modulos/p_navbar.php");

// Manejo de la actualización del usuario
if (isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $rol = $_POST['rol'];

    $sql = "UPDATE usuarios SET nombre='$nombre', correo='$correo', rol='$rol' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Usuario actualizado con éxito."); window.location.href="registro_usuario.php";</script>';
    } else {
        echo '<script>alert("Error al actualizar usuario.");</script>';
    }
}

// Manejo de la visualización del formulario de edición
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM usuarios WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Editar Usuario</h1>
        <form action="editar.php" method="post">
            <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre</label>
                <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo $user['nombre']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="correo" class="form-label">Correo</label>
                <input type="email" class="form-control" name="correo" id="correo" value="<?php echo $user['correo']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="rol" class="form-label">Rol</label>
                <select class="form-select" name="rol" id="rol" required>
                    <option value="Administrador" <?php echo $user['rol'] == 'Administrador' ? 'selected' : ''; ?>>Administrador</option>
                    <option value="Usuario" <?php echo $user['rol'] == 'Usuario' ? 'selected' : ''; ?>>Usuario</option>
                </select>
            </div>
            <button type="submit" name="editar" class="btn btn-warning">Actualizar</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
