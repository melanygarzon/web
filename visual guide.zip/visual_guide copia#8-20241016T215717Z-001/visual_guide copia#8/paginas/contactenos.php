<?php  
    include_once("../modulos/header.php");
    include_once("../modulos/p_navbar.php");
?>
<head>
    <link rel="stylesheet" href="../modulos/contact.css">
    <link href="https://fonts.googleapis.com/css2?family=Megalopolis+Extra&display=swap" rel="stylesheet">
    <style>
        body {
            background-image: url("../img/fondo_vg.jpg"); /* Ruta de la imagen de fondo */
            background-size: cover; /* Ajusta el tamaño de la imagen para cubrir toda la pantalla */
            background-repeat: no-repeat; /* Evita que la imagen se repita */
            background-position: center; /* Centra la imagen de fondo */
        }
    </style>
    
</head>

<div class="contact-container">
    <h1>Aquí podrás encontrar nuestro contacto</h1>
    <p>¡Nos encantaría saber de ti! Tu opinión es muy importante para nosotros.</p>
    <p>Por favor, utiliza los siguientes canales para comunicarnos tus dudas o comentarios:</p>

    <div class="contact-info">
        <small>
            <i class="fab fa-instagram"></i> Instagram: 
            <a href="https://www.instagram.com/visualguide04?igsh=MXI5eHJieHVtYTdiYw%3D%3D&utm_source=qr">oasis_spa02</a>
        </small>
        <br>
        <small>
            <i class="fab fa-whatsapp"></i> WhatsApp: 
            <a href="https://wa.me/3242621070">Visual Guide</a>
        </small>
        <br>
        <small>
            <i class="fas fa-envelope"></i> Correo Electrónico: 
            <a href="mailto:ejemplo@correo.com">ejemplo@correo.com</a>
        </small>
    </div>
    
    <p>Estamos aquí para ayudarte. Si tienes alguna pregunta, no dudes en contactarnos.</p>
    <p>Agradecemos tu interés y estaremos encantados de atenderte.</p>
    <p>Síguenos en nuestras redes sociales para estar al tanto de las últimas noticias y ofertas.</p>
</div>
