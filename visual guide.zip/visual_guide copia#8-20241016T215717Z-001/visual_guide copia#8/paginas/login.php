<?php
  include_once("../modulos/header.php");
  include_once("../modulos/p_navbar.php");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
    <link rel="stylesheet" href="../modulos/login2.css">

</head> 
<body>
    
<div class="login-box">
  <h2>Login</h2>
  <form action="../modulos/validar_login.php" method="post">
    <div class="user-box">
      <input 
      type="email"
      id="correo"
      name="correo"
      aria-describedby="emailHelp"
      required
      >
      <label>Ingrese su correo</label>
    </div>
    <div class="user-box">
      <input 
      type="password"
      id="clave"
      name="clave" 
      required
      >
      <label>Ingrese su clave</label>
    </div>
    

   <center>
    <button
    type="submit"
    name ="ingresar" 
    class="btn btn">Ingresar</button>
     
    </center>

  </form>
  <center> <small><a href="../paginas/registro.php">Registrese  Aquí</a></small></center>

</div>
    
</body>
</html>

