<?php 
    include_once("../modulos/header.php");
    include_once("../modulos/p_navbar.php");

?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <title>Productos</title>
    <link rel="stylesheet" href="../modulos/style.css">
    <link rel="stylesheet" href="../modulos/Tienda.css">
    <link rel="preconnect" href="import 'google_fonts';"> 
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/8a9066c40b.js" crossorigin="anonymous"></script>
</head>
  <body>
 <!--PROGUCTOS-->
<div class="title-cards">
    <h2>MODELOS DE BASTONES</h2>
</div>

<div class="container-card">
    
    <div class="card"  >

        <figure>
            <img src="../img/baston1.jpg">
        </figure>

        <div class="contenido-card">
            <h3>BASTON ELECTRONICO</h3>
            <p>1.490.000 $.</p>
            <a href="#">COMPRAR</a>
        </div>

    </div>
    <div class="card">

        <figure>
            <img src="../img/baston2.png">
        </figure>

        <div class="contenido-card">
            <h3>BASTON NORMAL</h3>
            <p>169.000 $.</p>
            <a href="#">COMPRAR</a>
        </div>

    </div>
    

    </div>

</div>
  

  </body>



    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>





<?php
    include_once("../modulos/footer.php");
?>