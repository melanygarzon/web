<?php 
    include_once("../modulos/header.php");
    include_once("../modulos/p_navbar.php");
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Repuestos</title>
  <link rel="stylesheet" href="../modulos/Tienda.css">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/8a9066c40b.js" crossorigin="anonymous"></script>
</head>

<body>
<div class="title-cards">
    <h2>Modelos de Repuestos</h2>
</div>

<div class="container">
<div class="container-card">
    <div class="card">
        <figure>
            <img src="../img/repuesto1.jpg" alt="Repuesto 1">
        </figure>
        <div class="contenido-card">
            <h3>Repuesto 1</h3>
            <p>Descripción del repuesto 1.</p>
            <h3>Precio: $$$$</h3>
            <a href="#">Comprar Ahora</a>
        </div>
    </div>

    <div class="card">
        <figure>
            <img src="../img/repuesto2.jpg" alt="Repuesto 2">
        </figure>
        <div class="contenido-card">
            <h3>Repuesto 2</h3>
            <p>Descripción del repuesto 2.</p>
            <h3>Precio: $$$$</h3>
            <a href="#">Comprar Ahora</a>
        </div>
    </div>

    <div class="card">
        <figure>
            <img src="../img/repuesto3.jpg" alt="Repuesto 3">
        </figure>
        <div class="contenido-card">
            <h3>Repuesto 3</h3>
            <p>Descripción del repuesto 3.</p>
            <h3>Precio: $$$$</h3>
            <a href="#">Comprar Ahora</a>
        </div>
    </div>

    <div class="card">
        <figure>
            <img src="../img/repuesto4.jpg" alt="Repuesto 4">
        </figure>
        <div class="contenido-card">
            <h3>Repuesto 4</h3>
            <p>Descripción del repuesto 4.</p>
            <h3>Precio: $$$$</h3>
            <a href="#">Comprar Ahora</a>
        </div>
    </div>
</div>
</div>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
    include_once("../modulos/footer.php");
?>
