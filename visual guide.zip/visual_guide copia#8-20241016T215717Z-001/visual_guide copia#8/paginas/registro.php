<?php 
    include_once("../modulos/header.php");
    include_once("../modulos/p_navbar.php");
    include_once("../modulos/conexion.php"); // Conexión a la base de datos

    if (isset($_POST['registro'])) {
        $nombre = $_POST['nombre'];
        $correo = $_POST['correo'];
        $clave = $_POST['clave'];
        $invidente = $_POST['invidente']; 

        $clave_encriptada = password_hash($clave, PASSWORD_DEFAULT);

        $rol = "usuario";

        $sql = "INSERT INTO usuarios (nombre, correo, clave, invidente, rol) VALUES ('$nombre', '$correo', '$clave_encriptada', '$invidente', '$rol')";

        if (mysqli_query($conn, $sql)) {
            echo '<script>alert("Registro exitoso. Ahora puede iniciar sesión."); window.location.href = "login.php";</script>';
        } else {
            echo '<script>alert("Error en el registro. Intente nuevamente."); window.location.href = "registro.php";</script>';
        }
    }
?>
<html>
<head>
    <link rel="stylesheet" href="http://localhost/visual_guide/modulos/login2.css">
</head>
<body>
<div class="login-box">
  <div class="tab-content">
    <div id="signup">   
      <h1>Registrate</h1>
      
      <form action="registro.php" method="post">
        <div class="">
          <div class="field-wrap">
            <label>
              Ingresa un Nombre<span class="req">*</span>
            </label>  
            <input type="text" name="nombre" required autocomplete="off"/>
          </div>
        </div>

        <div class="field-wrap">
          <label>
            Ingresa un Correo<span class="req">*</span>
          </label>
          <input type="email" name="correo" required autocomplete="off"/>
        </div>
        
        <div class="field-wrap">
          <label>
            Ingresa una Contraseña<span class="req">*</span>
          </label>
          <input type="password" name="clave" required autocomplete="off"/>
        </div>
        
        <div class="field-wrap">
          <label>¿Tiene una discapacidad visual?</label>
          <select class="user-box input" name="invidente" required>
            <option value="" disabled selected>Seleccione una opción</option>
            <option value="si">Sí</option>
            <option value="no">No</option>
          </select>
        </div>

        <br>
        
        <button type="submit" name="registro" class="btn btn-primary">Ingresar</button>

        <small><center>Si ya se ha registrado y quiere iniciar sesión haga clic <a href="login.php">aquí</a></center></small>
      </form>

    </div>
  </div>
</div>

<?php
   // include_once("../modulos/footer.php");
?>
</body>
</html>
