<head>
<style>
body {
    background-image: url('../img/fondo_vg.jpg'); 
    background-size: cover;
    background-position: center;
}   
form {
    background-color: rgba(0, 128, 0, 0.3); 
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
}

button.btn {
    background-color: #90ee90; 
    color: #fff; 
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    transition: box-shadow 0.3s ease; 
}

button.btn:hover {
    box-shadow: 0 0 10px 2px rgba(0, 255, 0, 0.8); 
    cursor: pointer;
}
</style>

</head>
<?php
include_once("../modulos/header.php");
include_once("../modulos/p_navbar.php");
include_once("../modulos/conexion.php");

if (isset($_POST['registro'])) {
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $cantidad = $_POST['cantidad'];

    $sql = "INSERT INTO repuestos (nombre, descripcion, precio, cantidad) VALUES ('$nombre', '$descripcion', '$precio', '$cantidad')";
    
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Repuesto registrado con éxito.");</script>';
    } else {
        echo '<script>alert("Error al registrar repuesto.");</script>';
    }
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM repuestos WHERE id = $id";
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Repuesto eliminado con éxito.");</script>';
    } else {
        echo '<script>alert("Error al eliminar repuesto.");</script>';
    }
}

if (isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $cantidad = $_POST['cantidad'];

    $sql = "UPDATE repuestos SET nombre='$nombre', descripcion='$descripcion', precio='$precio', cantidad='$cantidad' WHERE id=$id";
    
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Repuesto actualizado con éxito.");</script>';
    } else {
        echo '<script>alert("Error al actualizar repuesto.");</script>';
    }
}

$sql = "SELECT * FROM repuestos";
$result = mysqli_query($conn, $sql);
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="h-100 p-5 text-white bg- border rounded-1">
            <h2>Datos del Repuesto</h2>
            <div class="container">
                <form action="" method="post">
                    <div class="mb-3">
                      <label for="" class="form-label">Nombre del Repuesto</label>
                      <input type="text" class="form-control" name="nombre" placeholder="Nombre del repuesto" required>
                      <small class="form-text text-muted">Nombre del Repuesto</small>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Descripción</label>
                      <textarea class="form-control" name="descripcion" placeholder="Descripción del repuesto" required></textarea>
                      <small class="form-text text-muted">Descripción del Repuesto</small>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Precio</label>
                      <input type="number" class="form-control" name="precio" step="0.01" placeholder="Precio del repuesto" required>
                      <small class="form-text text-muted">Precio en USD</small>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Cantidad</label>
                      <input type="number" class="form-control" name="cantidad" placeholder="Cantidad disponible" required>
                      <small class="form-text text-muted">Cantidad del Repuesto</small>
                    </div>
                    <button type="submit" name="registro" class="btn btn-">Registrar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Tabla de Repuestos -->
<br>
<hr>
<br>
<div class="table-responsive">
    <table class="table table-striped table-hover table-borderless table-primary align-middle">
        <thead class="table-light">
            <caption>Lista de Repuestos</caption>
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody class="table-group-divider">
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr class="table-primary">
                    <td><?php echo $row['nombre']; ?></td>
                    <td><?php echo $row['descripcion']; ?></td>
                    <td><?php echo $row['precio']; ?></td>
                    <td><?php echo $row['cantidad']; ?></td>
                    <td>
                        <a href="edi_repuestos.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Editar</a>
                        <a href="?delete=<?php echo $row['id']; ?>" class="btn btn-danger">Eliminar</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php
include_once("../modulos/footer.php");
?>
