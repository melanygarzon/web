<?php
include_once("../modulos/conexion.php");
include_once("../modulos/header.php");
include_once("../modulos/p_navbar.php");

mysqli_set_charset($conn, "utf8mb4");

if (isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $precio = $_POST['precio'];
    $descripcion = $_POST['descripcion'];
    $stock = $_POST['stock'];
    $tipo = $_POST['tipo'];
    $foto = $_POST['foto'];

    $sql = "UPDATE productos SET nombre='$nombre', precio='$precio', descrip='$descripcion', stock='$stock', tipo='$tipo', foto='$foto' WHERE id=$id";
    
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Producto actualizado con éxito."); window.location.href="productos.php";</script>';
    } else {
        echo '<script>alert("Error al actualizar el producto.");</script>';
    }
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM productos WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $producto = mysqli_fetch_assoc($result);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Editar Producto</h1>
        <form action="edi_productos.php" method="post">
            <input type="hidden" name="id" value="<?php echo $producto['id']; ?>">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre del Producto</label>
                <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo htmlspecialchars($producto['nombre'], ENT_QUOTES, 'UTF-8'); ?>" required>
            </div>
            <div class="mb-3">
                <label for="descripcion" class="form-label">Descripción</label>
                <textarea class="form-control" name="descripcion" id="descripcion" required><?php echo htmlspecialchars($producto['descrip'], ENT_QUOTES, 'UTF-8'); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="precio" class="form-label">Precio</label>
                <input type="number" class="form-control" name="precio" id="precio" value="<?php echo $producto['precio']; ?>" step="0.01" required>
            </div>
            <div class="mb-3">
                <label for="stock" class="form-label">Stock</label>
                <input type="number" class="form-control" name="stock" id="stock" value="<?php echo $producto['stock']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="tipo" class="form-label">Tipo de Producto</label>
                <select class="form-select" name="tipo" required>
                    <option value="" disabled>Seleccionar tipo</option>
                    <option value="Electrónico" <?php if ($producto['tipo'] == 'Electrónico') echo 'selected'; ?>>Electrónico</option>
                    <option value="Mecánico" <?php if ($producto['tipo'] == 'Mecánico') echo 'selected'; ?>>Mecánico</option>
                    <option value="Accesorio" <?php if ($producto['tipo'] == 'Accesorio') echo 'selected'; ?>>Accesorio</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="foto" class="form-label">URL de la Foto</label>
                <input type="text" class="form-control" name="foto" id="foto" value="<?php echo htmlspecialchars($producto['foto'], ENT_QUOTES, 'UTF-8'); ?>" required>
                <small class="form-text text-muted">Ingrese la URL de la imagen del producto</small>
            </div>
            <button type="submit" name="editar" class="btn btn-warning">Actualizar</button>
        </form>
    </div>
</body>
</html>
