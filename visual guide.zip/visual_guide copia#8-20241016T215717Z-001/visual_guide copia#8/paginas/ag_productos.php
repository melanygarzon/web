<head>
<style>
body {
    background-image: url('../img/fondo_vg.jpg'); 
    background-size: cover;
    background-position: center;
}
form {
    
    background-color: rgba(0, 128, 0, 0.3); 
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
}

button.btn {
    background-color: #90ee90; 
    color: #fff; 
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    transition: box-shadow 0.3s ease; 
}

button.btn:hover {
    box-shadow: 0 0 10px 2px rgba(0, 255, 0, 0.8); 
    cursor: pointer;
}
</style>

</head>
<?php
include_once("../modulos/header.php");
include_once("../modulos/p_navbar.php");
include_once("../modulos/conexion.php");

if (isset($_POST['registro'])) {
    $nombre = $_POST['nombre'];
    $precio = $_POST['precio'];
    $descripcion = $_POST['descripcion'];
    $stock = $_POST['stock'];
    $tipo = $_POST['tipo'];
    $foto = $_POST['foto']; 

    $sql = "INSERT INTO productos (nombre, precio, descrip, stock, tipo, foto) VALUES ('$nombre', '$precio', '$descripcion', '$stock', '$tipo', '$foto')";
    
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Producto registrado con éxito.");</script>';
    } else {
        echo '<script>alert("Error al registrar producto.");</script>';
    }
}


if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM productos WHERE id = $id";
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Producto eliminado con éxito.");</script>';
    } else {
        echo '<script>alert("Error al eliminar producto.");</script>';
    }
}

if (isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $precio = $_POST['precio'];
    $descripcion = $_POST['descripcion'];
    $stock = $_POST['stock'];
    $tipo = $_POST['tipo'];
    $foto = $_POST['foto']; 

    $sql = "UPDATE productos SET nombre='$nombre', precio='$precio', descrip='$descripcion', stock='$stock', tipo='$tipo', foto='$foto' WHERE id=$id";
    
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Producto actualizado con éxito.");</script>';
    } else {
        echo '<script>alert("Error al actualizar producto.");</script>';
    }
}

$sql = "SELECT * FROM productos";
$result = mysqli_query($conn, $sql);
?>


<!-- Formulario Productos -->
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="h-100 p-5 text-white bg- border rounded-1">
            <h2>Datos del Producto para registrar</h2>
            <div class="container">
                <form action="" method="post">
                    <div class="mb-3">
                      <label for="" class="form-label">Nombre del Producto</label>
                      <input type="text" class="form-control" name="nombre" placeholder="Nombre del producto" required>
                      <small class="form-text text-muted">Nombre del Producto</small>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Descripción</label>
                      <textarea class="form-control" name="descripcion" placeholder="Descripción del producto" required></textarea>
                      <small class="form-text text-muted">Descripción del Producto</small>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Precio</label>
                      <input type="number" class="form-control" name="precio" step="0.01" placeholder="Precio del producto" required>
                      <small class="form-text text-muted">Precio en USD</small>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Stock</label>
                      <input type="number" class="form-control" name="stock" placeholder="Cantidad disponible" required>
                      <small class="form-text text-muted">Cantidad de Producto en Inventario</small>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Tipo de Producto</label>
                        <select class="form-select" name="tipo" required>
                            <option value="" disabled selected>Seleccionar tipo</option>
                            <option value="Electrónico">Electrónico</option>
                            <option value="Mecánico">Mecánico</option>
                            <option value="Accesorio">Accesorio</option>
                        </select>
                        <small class="form-text text-muted">Tipo de Producto</small>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">URL de la Foto</label>
                        <input type="text" class="form-control" name="foto" placeholder="URL de la imagen" required>
                        <small class="form-text text-muted">Ingrese la URL de la imagen del producto</small>
                    </div>
                    <button type="submit" name="registro" class="btn btn-">Registrar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Tabla de Productos -->
<br>
<hr>
<br>
<div class="table-responsive">
    <table class="table table-striped table-hover table-borderless table-primary align-middle">
        <thead class="table-light">
            <caption>Lista de Productos</caption>
            <tr>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Precio</th>
                <th>Stock</th>
                <th>Tipo</th>
                <th>Foto</th> 
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody class="table-group-divider">
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr class="table-primary">
                    <td><?php echo $row['nombre']; ?></td>
                    <td><?php echo $row['descrip']; ?></td>
                    <td><?php echo $row['precio']; ?></td>
                    <td><?php echo $row['stock']; ?></td>
                    <td><?php echo $row['tipo']; ?></td>
                    <td>
                        <img src="<?php echo $row['foto']; ?>" alt="Foto del Producto" style="width: 50px; height: 50px;">
                    </td>
                    <td>
                        <a href="edi_productos.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Editar</a>
                        <a href="?delete=<?php echo $row['id']; ?>" class="btn btn-danger">Eliminar</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php
include_once("../modulos/footer.php");
?>
