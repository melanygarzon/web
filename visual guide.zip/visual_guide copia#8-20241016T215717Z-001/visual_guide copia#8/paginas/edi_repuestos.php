<?php
include_once("../modulos/conexion.php");
include_once("../modulos/header.php");
include_once("../modulos/p_navbar.php");

if (isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $cantidad = $_POST['cantidad'];

    $sql = "UPDATE repuestos SET nombre='$nombre', descripcion='$descripcion', precio='$precio', cantidad='$cantidad' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Repuesto actualizado con éxito."); window.location.href="repuestos.php";</script>';
    } else {
        echo '<script>alert("Error al actualizar el repuesto.");</script>';
    }
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM repuestos WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $repuesto = mysqli_fetch_assoc($result);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Repuesto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Editar Repuesto</h1>
        <form action="edi_repuestos.php" method="post">
            <input type="hidden" name="id" value="<?php echo $repuesto['id']; ?>">
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre del Repuesto</label>
                <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo $repuesto['nombre']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="descripcion" class="form-label">Descripción</label>
                <textarea class="form-control" name="descripcion" id="descripcion" required><?php echo $repuesto['descripcion']; ?></textarea>
            </div>
            <div class="mb-3">
                <label for="precio" class="form-label">Precio</label>
                <input type="number" class="form-control" name="precio" id="precio" value="<?php echo $repuesto['precio']; ?>" step="0.01" required>
            </div>
            <div class="mb-3">
                <label for="cantidad" class="form-label">Cantidad</label>
                <input type="number" class="form-control" name="cantidad" id="cantidad" value="<?php echo $repuesto['cantidad']; ?>" required>
            </div>
            <button type="submit" name="editar" class="btn btn-warning">Actualizar</button>
        </form>
    </div>

    
