<?php 
    include_once("../modulos/header.php");
    include_once("../modulos/p_navbar.php");
?>


    <!-- Estilo -->
  <style>   
    /* Estilos generales */
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #000;
    color: #fff;
}

header {
    background-color: #000;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px;
}

header .logo {
    font-size: 24px;
    color: #acf5a0;
}

nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
}

nav ul li {
    margin-right: 20px;
}

nav ul li a {
    color: #acf5a0;
    text-decoration: none;
    font-size: 18px;
}

.hero {
    text-align: center;
    padding: 50px 20px;
    background-color: #fff;
    color: #000;
}

.hero h1 {
    font-size: 36px;
    color: #acf5a0;
}

.hero p {
    font-size: 20px;
    margin-top: 10px;
    margin-bottom: 20px;
    color: #333;
}

.cta {
    background-color: #acf5a0;
    color: #000;
    border: none;
    padding: 15px 30px;
    font-size: 18px;
    cursor: pointer;
}

.cta:hover {
    background-color: #acf5a0;
}

.features {
    display: flex;
    justify-content: space-around;
    padding: 50px 20px;
    background-color: #000;
    color: #fff;
}

.feature {
    text-align: center;
}

.feature img {
    width: 100px;
    height: 100px;
}

.feature h3 {
    color: #acf5a0;
    margin: 15px 0;
}

.benefits {
    display: flex;
    justify-content: space-around;
    padding: 50px 20px;
    background-color: #fff;
    color: #000;
}

.benefit h2 {
    color: #acf5a0;
}

.testimonials {
    background-color: #000;
    padding: 50px 20px;
}

.testimonial {
    text-align: center;
    margin-bottom: 30px;
}

footer {
    background-color: #000;
    padding: 20px;
    text-align: center;
    color: #fff;
}

footer .social-icons a {
    margin-right: 10px;
    color: #acf5a0;
    text-decoration: none;
}

footer .social-icons a:hover {
    color: #acf5a0;
}
</style>

    <!-- Presentación del Producto -->
    <section class="hero">
        <h1>La tecnología al servicio de tu movilidad</h1>
        <p>Detecta obstáculos en tiempo real con facilidad y seguridad.</p>
        <button class="cta">Comprar Ahora</button>
    </section>

    <!-- Características del Producto -->
    <section class="features">
        <div class="feature">
            <img src="../img/onda.png" alt="Sensor ultrasónico">
            <h3>Sensor ultrasónico</h3>
            <p>Detecta obstáculos a distancia con precisión.</p>
        </div>
        <div class="feature">
            <img src="../img/bateria.webp" alt="Batería de larga duración">
            <h3>Batería de larga duración</h3>
            <p>Duración prolongada para acompañarte todo el día.</p>
        </div>
        <div class="feature">
            <img src="../img/alarma.png" alt="Alarma de proximidad">
            <h3>Alarma de proximidad</h3>
            <p>Avisa al usuario de posibles obstáculos cercanos.</p>
        </div>
    </section>

    <!-- Beneficios -->
    <section class="benefits">
        <div class="benefit">
            <h2>Mayor autonomía</h2>
            <p>Confianza y seguridad para desplazarte libremente.</p>
        </div>
        <div class="benefit">
            <h2>Fácil de usar</h2>
            <p>Interfaz intuitiva diseñada para todos.</p>
        </div>
        <div class="benefit">
            <h2>Compacto y ergonómico</h2>
            <p>Ligero y cómodo para uso prolongado.</p>
        </div>
    </section>

    <?php
    include_once("../modulos/footer.php");
    ?> 
