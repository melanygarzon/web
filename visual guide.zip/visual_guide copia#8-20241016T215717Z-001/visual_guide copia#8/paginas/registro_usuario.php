<?php
include_once("../modulos/header.php");
include_once("../modulos/p_navbar.php");
include_once("../modulos/conexion.php");

if (isset($_POST['registro'])) {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $clave = $_POST['clave'];
    $rol = $_POST['rol'];

    // Encriptar la contraseña
    $clave_encriptada = password_hash($clave, PASSWORD_DEFAULT);

     $sql = "INSERT INTO usuarios (nombre, correo, clave, rol) VALUES ('$nombre', '$correo', '$clave_encriptada', '$rol')";
    
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Usuario registrado con éxito.");</script>';
    } else {
        echo '<script>alert("Error al registrar usuario.");</script>';
    }
}

// elimina usuarios
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    $sql = "DELETE FROM usuarios WHERE id = $id";
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Usuario eliminado con éxito.");</script>';
    } else {
        echo '<script>alert("Error al eliminar usuario.");</script>';
    }
}

//  edición usuarios
if (isset($_POST['editar'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $clave = $_POST['clave'];
    $rol = $_POST['rol'];

    // Encriptar la contraseña si ha sido cambiada
    $clave_encriptada = password_hash($clave, PASSWORD_DEFAULT);

    $sql = "UPDATE usuarios SET nombre='$nombre', correo='$correo', clave='$clave_encriptada', rol='$rol' WHERE id=$id";
    
    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Usuario actualizado con éxito.");</script>';
    } else {
        echo '<script>alert("Error al actualizar usuario.");</script>';
    }
}

$sql = "SELECT * FROM usuarios";
$result = mysqli_query($conn, $sql);
?>

<h1><center>Registre usuarios</center></h1>

<!-- Formulario de Registro -->
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="h-100 p-5 text-white bg-info border rounded-1">
            <h2>Datos del Usuario</h2>
            <div class="container">
                <form action="" method="post">
                    <div class="mb-3">
                      <label for="" class="form-label">Nombre</label>
                      <input type="text" class="form-control" name="nombre" placeholder="Nombre completo" required>
                      <small class="form-text text-muted">Nombre del Usuario</small>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Email</label>
                      <input type="email" class="form-control" name="correo" placeholder="abc@mail.com" required>
                      <small class="form-text text-muted">Correo del usuario</small>
                    </div>
                    <div class="mb-3">
                      <label for="" class="form-label">Contraseña</label>
                      <input type="password" class="form-control" name="clave" placeholder="" required>
                      <small class="form-text text-muted">Contraseña del Usuario</small>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label">Seleccione rol</label>
                        <select class="form-select form-select-lg" name="rol" required>
                            <option value="" disabled selected>Seleccionar rol</option>
                            <option value="Administrador">Administrador</option>
                            <option value="Usuario">Usuario</option>
                        </select>
                    </div>
                    <button type="submit" name="registro" class="btn btn-warning">Registrar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Tabla de Usuarios -->
<br>
<hr>
<br>
<div class="table-responsive">
    <table class="table table-striped table-hover table-borderless table-primary align-middle">
        <thead class="table-light">
            <caption>Usuarios del Sistema</caption>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Contraseña</th>
                <th>Rol</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody class="table-group-divider">
            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr class="table-primary">
                    <td><?php echo $row['nombre']; ?></td>
                    <td><?php echo $row['correo']; ?></td>
                    <td><?php echo $row['clave']; ?></td>
                    <td><?php echo $row['rol']; ?></td>
                    <td>
                        <a href="editar.php?id=<?php echo $row['id']; ?>" class="btn btn-primary">Editar</a>
                        <a href="?delete=<?php echo $row['id']; ?>" class="btn btn-danger">Eliminar</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>
<?php
   include_once("../modulos/footer.php");
?>
