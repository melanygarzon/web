<?php
    $host="localhost";
    $user="root";
    $pass="";
    $db="visual_guide";

    $conn = mysqli_connect($host,$user,$pass,$db);

    try {
        $conn = mysqli_connect($host,$user,$pass,$db);
    } catch(Exception $e) {
        echo  "Error conectando a la base de batos : " . $e->getMessage();
    }
    
?>