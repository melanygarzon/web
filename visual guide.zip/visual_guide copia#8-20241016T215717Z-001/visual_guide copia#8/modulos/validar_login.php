
<h4>Si funciona</h4>
 
<?php

    include_once ("conexion.php");       
    if (isset($_POST['ingresar'])){
        $correo=$_POST['correo'];
        $clave=$_POST['clave'];

        $sql = "SELECT * FROM usuarios WHERE correo = '$correo'";
        $resul= mysqli_query($conn,$sql);
        $numReg = mysqli_num_rows($resul);
        if ($numReg){
            echo("El correo existe   ");
            $regi= mysqli_fetch_array($resul);
            $veriClave = password_verify($clave,$regi['clave']);
            if ($veriClave){ 

                session_start();
                $_SESSION['id_usuario']  = $regi['id'];
                $_SESSION['nombre']  = $regi['nombre'];
                $_SESSION['rol']  = $regi['rol'];
                echo ("Bienvenido,   " .$_SESSION['nombre']);
                
                echo'<script tyipe= "text/javascript">
                alert("Bienvenido, '.$_SESSION['nombre'].' ");
                window.location.href = "http://localhost/visual_guide/index.php";
                </script>';

                }else{
                
                echo'<script tyipe= "text/javascript">
                alert("La contraseña es incorrecta ");
                window.location.href = "http://localhost/visual_guide/paginas/login.php";
                </script>';
            }
               
            }else{
                echo'<script tyipe= "text/javascript">
                    alert("El correo no es existe ");
                    window.location.href = "http://localhost/visual_guide/paginas/login.php";
                    </script>';
        }

    }

?>