<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" 
          href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .nav-link:hover {
            color: #acf5a0; /* Color al pasar el mouse */
        }
        .dropdown-menu {
            background-color: #343a40; /* Color de fondo del dropdown */
        }
        .dropdown-item:hover {
            background-color: #495057; /* Color al pasar el mouse sobre el item */
        }
    </style>
</head>

<?php
session_start();
$usu = isset($_SESSION['nombre']) ? $_SESSION['nombre'] : '';
$rol = isset($_SESSION['rol']) ? $_SESSION['rol'] : '';
?>
<body>
<nav class="navbar navbar-expand-sm navbar-custom bg-dark">
    <div class="container">
        <a class="navbar-brand text-white" href="http://localhost/visual_guide/index.php">
            <img src="http://localhost/visual_guide/img/vg.jpg" alt="Visual Guide" 
                 width="60" height="60" class="rounded-circle">
            <span class="ms-2">Visual Guide</span>
        </a>
        <button class="navbar-toggler" type="button" 
                data-bs-toggle="collapse" data-bs-target="#collapsibleNavId"
                aria-controls="collapsibleNavId" aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="http://localhost/visual_guide/paginas/productos.php" aria-label="Productos">
                        <i class="fas fa-shopping-cart"></i> Productos
                    </a>
                </li>

                 <!-- Muestra el menú "Repuestos" solo si el usuario ha iniciado sesión -->
                 <?php if ($usu): ?>
                <li class="nav-item">
                    <a class="nav-link text-white" href="http://localhost/visual_guide/paginas/repuestos.php" aria-label="Repuestos">
                        <i class="fas fa-cogs"></i> Repuestos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="http://localhost/visual_guide/paginas/beneficios.php" aria-label="Beneficios">
                        <i class="fas fa-plus-circle"></i> Beneficios
                    </a>
                </li>
                <?php endif; ?>

                <!-- Muestra el menú "Agregar Productos" y "Agregar Repuestos" solo si es administrador -->
                <?php if ($rol == "administrador"): ?>
                <li class="nav-item">
                    <a class="nav-link text-white" href="http://localhost/visual_guide/paginas/ag_productos.php" aria-label="Agregar Productos">
                        <i class="fas fa-plus-circle"></i> Agregar Productos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="http://localhost/visual_guide/paginas/ag_repuestos.php" aria-label="Agregar Repuestos">
                        <i class="fas fa-plus-circle"></i> Agregar Repuestos
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="http://localhost/visual_guide/paginas/beneficios.php" aria-label="Beneficios">
                        <i class="fas fa-plus-circle"></i> Beneficios
                    </a>
                </li>
                <?php endif; ?>

               
                
                <?php if ($rol != "administrador"): ?>
                <li class="nav-item">
                    <a class="nav-link text-white" href="http://localhost/visual_guide/paginas/contactenos.php" aria-label="Contáctenos">
                        <i class="fas fa-envelope"></i> Contáctenos
                    </a>
                </li>
                <?php endif; ?>
            </ul>
            <div class="d-flex align-items-center">
                <span class="text-white me-3" aria-label="Usuario">
                    <b><?php echo $usu; ?> || <?php echo $rol; ?></b>
                </span>
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle text-white" href="#" 
                       id="dropdownId" data-bs-toggle="dropdown" 
                       aria-expanded="false" aria-label="Usuarios">
                       <i class="fas fa-user"></i> <?php if ($rol == "") { echo ' Usuarios'; } ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <?php if ($rol == ""): ?>
                            <li><a class="dropdown-item text-white" 
                                   href="http://localhost/visual_guide/paginas/login.php">
                                   Ingresar</a></li>
                            <li><a class="dropdown-item text-white" 
                                   href="http://localhost/visual_guide/paginas/registro.php">
                                   Regístrate</a></li>
                        <?php elseif ($rol == "usuario" || $rol == "administrador"): ?>
                            <li><a class="dropdown-item text-white" 
                                   href="http://localhost/visual_guide/modulos/salir.php">
                                   Cerrar Sesión</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>
